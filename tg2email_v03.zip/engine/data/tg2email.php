<?php
/**
 * Конфиг модуля tg2email
 * @var array
 */
$tg2emailConfig = [
    'tg2email_TOKEN' => '1234567890:abcdefghijklmnopqrstuvwxyzABCDE12345',
    'tg2email_CHATID' => '757940529',
    'tg2email_bufferTime' => 2,
    'tg2email_adminEmail' => 'mail@tcse-cms.com',
];
